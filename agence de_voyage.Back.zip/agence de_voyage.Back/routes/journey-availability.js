//disponibilité des voyages

const express = require('express');
const router = express.Router();


// Chercher les méthodes dans le dossier controller
const controller = require('../controllers/journey-availability');


// Dès qu'on va sur le chemin '/journey-availability', retourne les méthodes suivantes
router.get('/journey-availability', controller.getAll);
router.get('/journey-availability/:id', controller.get);
router.post('/journey-availability', controller.add);
router.put('/journey-availability/:id', controller.edit);
router.delete('/journey-availability/:id', controller.remove);


module.exports = router;